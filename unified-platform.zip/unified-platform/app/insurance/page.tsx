'use client'

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { SectionHeader } from "@/components/ui/section-header"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { QrCodeIcon as QRCode, Shield, Clock, Hospital, FileText } from 'lucide-react'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"

const INSURANCE_DETAILS = {
  planType: "Comprehensive Coverage",
  memberId: "1234 5678 9012 3456",
  group: "GRP123456789",
  effectiveDate: "01/01/2024",
  expirationDate: "12/31/2024",
  network: "Preferred Provider Network",
  deductible: {
    individual: 1000,
    family: 3000,
    remaining: 750
  },
  coverage: {
    medical: "90%",
    dental: "80%",
    vision: "80%",
    prescription: "75%"
  }
}

const RECENT_CLAIMS = [
  { date: "2024-01-15", provider: "City Hospital", amount: 150.00, status: "Approved" },
  { date: "2024-01-10", provider: "Dental Care", amount: 75.00, status: "Processing" },
  { date: "2024-01-05", provider: "Vision Center", amount: 200.00, status: "Approved" },
]

export default function InsurancePage() {
  const [activeTab, setActiveTab] = useState("card")

  return (
    <div className="container mx-auto py-8">
      <SectionHeader 
        title="Unified Insurance"
        description="Your comprehensive insurance management hub"
      />
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="card">
            <QRCode className="h-4 w-4 mr-2" />
            Card
          </TabsTrigger>
          <TabsTrigger value="coverage">
            <Shield className="h-4 w-4 mr-2" />
            Coverage
          </TabsTrigger>
          <TabsTrigger value="claims">
            <FileText className="h-4 w-4 mr-2" />
            Claims
          </TabsTrigger>
          <TabsTrigger value="network">
            <Hospital className="h-4 w-4 mr-2" />
            Network
          </TabsTrigger>
        </TabsList>

        <div className="mt-6">
          <TabsContent value="card">
            <div className="grid md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Digital Insurance Card</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="w-full aspect-[1.586/1] bg-gradient-to-br from-primary/20 to-primary rounded-lg p-6">
                    <div className="flex flex-col h-full justify-between text-white">
                      <div>
                        <h3 className="font-bold">Universal Healthcare</h3>
                        <p className="text-sm opacity-80">Premium Plan</p>
                      </div>
                      <div className="space-y-2">
                        <div>
                          <p className="text-sm opacity-80">Member ID</p>
                          <p className="font-mono">{INSURANCE_DETAILS.memberId}</p>
                        </div>
                        <div>
                          <p className="text-sm opacity-80">Group Number</p>
                          <p className="font-mono">{INSURANCE_DETAILS.group}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  <Dialog>
                    <DialogTrigger asChild>
                      <Button className="w-full">
                        <QRCode className="mr-2 h-4 w-4" />
                        Show QR Code
                      </Button>
                    </DialogTrigger>
                    <DialogContent>
                      <DialogHeader>
                        <DialogTitle>Insurance QR Code</DialogTitle>
                        <DialogDescription>
                          Scan this code at healthcare providers for quick authentication
                        </DialogDescription>
                      </DialogHeader>
                      <div className="w-full aspect-square bg-white rounded-lg flex items-center justify-center">
                        <QRCode className="h-48 w-48" />
                      </div>
                    </DialogContent>
                  </Dialog>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Plan Status</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg space-y-4">
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Plan Period</div>
                        <div className="flex items-center">
                          <Clock className="h-4 w-4 mr-2 text-primary" />
                          {INSURANCE_DETAILS.effectiveDate} - {INSURANCE_DETAILS.expirationDate}
                        </div>
                      </div>
                      <div>
                        <div className="text-sm text-muted-foreground mb-1">Deductible Progress</div>
                        <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                          <div 
                            className="h-full bg-primary"
                            style={{ width: `${(INSURANCE_DETAILS.deductible.remaining / INSURANCE_DETAILS.deductible.individual) * 100}%` }}
                          />
                        </div>
                        <div className="flex justify-between text-sm mt-1">
                          <span>${INSURANCE_DETAILS.deductible.remaining} remaining</span>
                          <span>${INSURANCE_DETAILS.deductible.individual} total</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="coverage">
            <Card>
              <CardHeader>
                <CardTitle>Coverage Details</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-6">
                  {Object.entries(INSURANCE_DETAILS.coverage).map(([type, percentage]) => (
                    <div key={type} className="p-4 border rounded-lg">
                      <div className="text-sm font-medium mb-2 capitalize">{type}</div>
                      <div className="text-2xl font-bold text-primary">{percentage}</div>
                      <div className="text-sm text-muted-foreground">Coverage</div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="claims">
            <Card>
              <CardHeader>
                <CardTitle>Recent Claims</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {RECENT_CLAIMS.map((claim, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <div className="font-medium">{claim.provider}</div>
                        <div className="text-sm text-muted-foreground">{claim.date}</div>
                      </div>
                      <div className="text-right">
                        <div className="font-medium">${claim.amount.toFixed(2)}</div>
                        <div className={`text-sm ${
                          claim.status === 'Approved' ? 'text-green-600' : 'text-yellow-600'
                        }`}>
                          {claim.status}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="network">
            <Card>
              <CardHeader>
                <CardTitle>Network Providers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    { name: "City Hospital", distance: "0.8 miles", type: "Hospital" },
                    { name: "Downtown Medical Center", distance: "1.2 miles", type: "Medical Center" },
                    { name: "Family Care Clinic", distance: "2.0 miles", type: "Clinic" },
                  ].map((provider, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <div className="font-medium">{provider.name}</div>
                        <div className="text-sm text-muted-foreground">{provider.type}</div>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {provider.distance}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </div>
      </Tabs>
    </div>
  )
}

