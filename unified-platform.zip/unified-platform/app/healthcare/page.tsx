'use client'

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { SectionHeader } from "@/components/ui/section-header"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { Camera, Scan, Brain, Activity, Heart, TreesIcon as Lungs, Eye } from 'lucide-react'
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

const SCAN_TYPES = [
  { id: 'xray', name: 'X-Ray', icon: Lungs, description: 'Deep tissue scanning' },
  { id: 'neural', name: 'Neural', icon: Brain, description: 'Brain activity monitoring' },
  { id: 'cardiac', name: 'Cardiac', icon: Heart, description: 'Heart monitoring' },
  { id: 'vision', name: 'Vision', icon: Eye, description: 'Eye examination' },
]

export default function HealthcarePage() {
  const [isScanning, setIsScanning] = useState(false)
  const [selectedScan, setSelectedScan] = useState('xray')
  const [scanResults, setScanResults] = useState<string[]>([])
  const [error, setError] = useState<string | null>(null)

  const handleScan = async () => {
    setIsScanning(true)
    setError(null)
    
    try {
      // Simulated scan process
      await new Promise(resolve => setTimeout(resolve, 2000))
      setScanResults(prev => [...prev, `Scan completed: ${new Date().toLocaleString()}`])
    } catch (err) {
      setError('Failed to complete scan. Please try again.')
    } finally {
      setIsScanning(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <SectionHeader 
        title="Unified Healthcare Imaging"
        description="Advanced medical imaging using smartphone sensors"
      />
      
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Camera Scanner</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Tabs value={selectedScan} onValueChange={setSelectedScan}>
                <TabsList className="grid grid-cols-2 lg:grid-cols-4">
                  {SCAN_TYPES.map(scan => (
                    <TabsTrigger key={scan.id} value={scan.id}>
                      <scan.icon className="mr-2 h-4 w-4" />
                      {scan.name}
                    </TabsTrigger>
                  ))}
                </TabsList>
                {SCAN_TYPES.map(scan => (
                  <TabsContent key={scan.id} value={scan.id}>
                    <div className="text-sm text-muted-foreground mb-4">
                      {scan.description}
                    </div>
                  </TabsContent>
                ))}
              </Tabs>

              <div className="w-full aspect-video bg-muted rounded-lg flex items-center justify-center">
                {isScanning ? (
                  <LoadingSpinner />
                ) : (
                  <Camera className="h-12 w-12" />
                )}
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                <Button 
                  onClick={handleScan}
                  disabled={isScanning}
                >
                  {isScanning ? "Scanning..." : "Start Scan"}
                </Button>
                <Button 
                  variant="outline"
                  onClick={() => setScanResults([])}
                  disabled={scanResults.length === 0}
                >
                  Clear History
                </Button>
              </div>
            </CardContent>
          </Card>

          {error && (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Scan Results</CardTitle>
            </CardHeader>
            <CardContent>
              {scanResults.length === 0 ? (
                <div className="text-muted-foreground text-center py-8">
                  No scans available
                </div>
              ) : (
                <div className="space-y-2">
                  {scanResults.map((result, i) => (
                    <div 
                      key={i}
                      className="p-3 bg-muted rounded-lg text-sm flex items-center"
                    >
                      <Activity className="h-4 w-4 mr-2 text-primary" />
                      {result}
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Real-time Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4">
                {[
                  { label: 'Heart Rate', value: '72 bpm' },
                  { label: 'Blood Pressure', value: '120/80' },
                  { label: 'Oxygen Level', value: '98%' },
                  { label: 'Temperature', value: '98.6°F' },
                ].map(metric => (
                  <div 
                    key={metric.label}
                    className="flex items-center justify-between p-2 border rounded"
                  >
                    <span className="text-sm text-muted-foreground">{metric.label}</span>
                    <span className="font-medium">{metric.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

