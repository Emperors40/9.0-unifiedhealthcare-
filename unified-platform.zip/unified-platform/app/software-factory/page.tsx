'use client'

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Code2, Bot, Upload } from 'lucide-react'
import { Progress } from "@/components/ui/progress"

export default function SoftwareFactoryPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Unified Software Factory</h1>
      
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>App Generator</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea 
              placeholder="Describe the app you want to create..."
              className="min-h-[150px]"
            />
            <Button className="w-full">
              <Code2 className="mr-2 h-4 w-4" />
              Generate Application
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>AI Agent Training</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 border rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Training Progress</span>
                <span className="text-sm text-muted-foreground">45%</span>
              </div>
              <Progress value={45} />
            </div>
            <div className="grid gap-4">
              <Button variant="outline" className="w-full">
                <Upload className="mr-2 h-4 w-4" />
                Upload Training Data
              </Button>
              <Button className="w-full">
                <Bot className="mr-2 h-4 w-4" />
                Start Training
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

