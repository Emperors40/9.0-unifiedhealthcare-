'use client'

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Environment } from '@react-three/drei'
import { Factory, Settings2, Play } from 'lucide-react'
import { Button } from "@/components/ui/button"

export default function ProductionPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Production Line Simulator</h1>
      
      <div className="grid lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Production Line Visualization</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="w-full aspect-[2/1] bg-muted rounded-lg overflow-hidden">
              <Canvas>
                <OrbitControls />
                <ambientLight intensity={0.5} />
                <Environment preset="warehouse" />
                {/* 3D production line would be rendered here */}
              </Canvas>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Controls</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="p-4 border rounded-lg space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Line Status</span>
                <span className="text-sm text-green-600">Operational</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Efficiency</span>
                <span className="text-sm">92%</span>
              </div>
            </div>
            <div className="grid gap-2">
              <Button className="w-full">
                <Play className="mr-2 h-4 w-4" />
                Start Simulation
              </Button>
              <Button variant="outline" className="w-full">
                <Settings2 className="mr-2 h-4 w-4" />
                Configure Line
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

