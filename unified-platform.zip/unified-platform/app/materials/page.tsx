'use client'

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { FlaskRoundIcon as Flask, MoveHorizontalIcon as MixerHorizontal, Printer } from 'lucide-react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Environment } from '@react-three/drei'

export default function MaterialsPage() {
  return (
    <div className="container mx-auto py-8">
      <h1 className="text-3xl font-bold mb-8">Raw Materials & Mixtures</h1>
      
      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Material Mixer</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid gap-4">
              <div>
                <label className="text-sm text-muted-foreground">Base Material</label>
                <Input placeholder="e.g., Polymer resin" />
              </div>
              <div>
                <label className="text-sm text-muted-foreground">Additives</label>
                <Input placeholder="e.g., Carbon fiber" />
              </div>
              <div>
                <label className="text-sm text-muted-foreground">Ratio</label>
                <Input placeholder="e.g., 70:30" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Button variant="outline">
                <MixerHorizontal className="mr-2 h-4 w-4" />
                Simulate Mix
              </Button>
              <Button>
                <Flask className="mr-2 h-4 w-4" />
                Create Mixture
              </Button>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Material Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="w-full aspect-square bg-muted rounded-lg overflow-hidden">
              <Canvas>
                <OrbitControls />
                <ambientLight intensity={0.5} />
                <Environment preset="warehouse" />
                {/* 3D material visualization would be rendered here */}
              </Canvas>
            </div>
            <Button className="w-full mt-4">
              <Printer className="mr-2 h-4 w-4" />
              Export for 3D Printing
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

