'use client'

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { SectionHeader } from "@/components/ui/section-header"
import { Slider } from "@/components/ui/slider"
import { LoadingSpinner } from "@/components/ui/loading-spinner"
import { Printer, Box, Settings2, Layers, Thermometer, Timer } from 'lucide-react'
import { Canvas } from '@react-three/fiber'
import { OrbitControls, Box as DreiBox, Environment, Text } from '@react-three/drei'
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const MATERIALS = [
  { id: 'pla', name: 'PLA', temp: '200°C' },
  { id: 'abs', name: 'ABS', temp: '230°C' },
  { id: 'petg', name: 'PETG', temp: '240°C' },
  { id: 'tpu', name: 'TPU', temp: '220°C' },
]

export default function PrintingPage() {
  const [isGenerating, setIsGenerating] = useState(false)
  const [isPrinting, setIsPrinting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [progress, setProgress] = useState(0)

  const handleGenerate = async () => {
    setIsGenerating(true)
    setError(null)
    try {
      await new Promise(resolve => setTimeout(resolve, 2000))
      setIsGenerating(false)
    } catch (err) {
      setError('Failed to generate model')
      setIsGenerating(false)
    }
  }

  const handlePrint = async () => {
    setIsPrinting(true)
    setError(null)
    setProgress(0)
    
    try {
      for (let i = 0; i <= 100; i += 10) {
        await new Promise(resolve => setTimeout(resolve, 1000))
        setProgress(i)
      }
    } catch (err) {
      setError('Print job failed')
    } finally {
      setIsPrinting(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <SectionHeader 
        title="Multi-Material 3D Printing"
        description="Design and print complex objects with multiple materials"
      />
      
      <div className="grid lg:grid-cols-2 gap-6">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Design Prompt</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Textarea 
                placeholder="Describe what you want to print..."
                className="min-h-[100px]"
              />
              
              <div className="grid gap-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm text-muted-foreground">Primary Material</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select material" />
                      </SelectTrigger>
                      <SelectContent>
                        {MATERIALS.map(material => (
                          <SelectItem key={material.id} value={material.id}>
                            {material.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm text-muted-foreground">Secondary Material</label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select material" />
                      </SelectTrigger>
                      <SelectContent>
                        {MATERIALS.map(material => (
                          <SelectItem key={material.id} value={material.id}>
                            {material.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">Layer Height (mm)</label>
                  <Slider 
                    defaultValue={[0.2]}
                    max={0.4}
                    min={0.1}
                    step={0.1}
                    className="w-full"
                  />
                </div>

                <div className="space-y-2">
                  <label className="text-sm text-muted-foreground">Infill Density (%)</label>
                  <Slider 
                    defaultValue={[20]}
                    max={100}
                    min={0}
                    step={5}
                    className="w-full"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <Button
                  onClick={handleGenerate}
                  disabled={isGenerating}
                >
                  {isGenerating ? (
                    <>Generating...</>
                  ) : (
                    <>
                      <Box className="mr-2 h-4 w-4" />
                      Generate Model
                    </>
                  )}
                </Button>
                <Button
                  variant="secondary"
                  onClick={handlePrint}
                  disabled={isPrinting}
                >
                  {isPrinting ? (
                    <>Printing...</>
                  ) : (
                    <>
                      <Printer className="mr-2 h-4 w-4" />
                      Start Print
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {error && (
            <Alert variant="destructive">
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Print Status</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {isPrinting && (
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>{progress}%</span>
                    </div>
                    <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                      <div 
                        className="h-full bg-primary transition-all duration-300"
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>
                )}

                <div className="grid grid-cols-2 gap-4">
                  {[
                    { icon: Thermometer, label: 'Nozzle Temp', value: '200°C' },
                    { icon: Thermometer, label: 'Bed Temp', value: '60°C' },
                    { icon: Layers, label: 'Layer', value: '45/180' },
                    { icon: Timer, label: 'Time Left', value: '2h 15m' },
                  ].map((stat, index) => (
                    <div key={index} className="flex items-center p-2 border rounded">
                      <stat.icon className="h-4 w-4 mr-2 text-primary" />
                      <div>
                        <div className="text-xs text-muted-foreground">{stat.label}</div>
                        <div className="font-medium">{stat.value}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="w-full aspect-square bg-muted rounded-lg overflow-hidden">
                {isGenerating ? (
                  <LoadingSpinner />
                ) : (
                  <Canvas>
                    <OrbitControls />
                    <ambientLight intensity={0.5} />
                    <pointLight position={[10, 10, 10]} />
                    <Environment preset="studio" />
                    <DreiBox args={[1, 1, 1]}>
                      <meshStandardMaterial color="hotpink" />
                    </DreiBox>
                    <Text
                      position={[0, -2, 0]}
                      fontSize={0.2}
                      color="black"
                    >
                      Preview Model
                    </Text>
                  </Canvas>
                )}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Print Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {[
                  { label: 'Print Speed', value: '60 mm/s' },
                  { label: 'Travel Speed', value: '120 mm/s' },
                  { label: 'Retraction Distance', value: '6.5 mm' },
                  { label: 'Retraction Speed', value: '25 mm/s' },
                ].map((setting, index) => (
                  <div key={index} className="flex justify-between items-center p-2 border rounded">
                    <span className="text-sm text-muted-foreground">{setting.label}</span>
                    <span className="font-medium">{setting.value}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

