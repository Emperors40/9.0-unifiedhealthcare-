'use client'

import { cn } from "@/lib/utils"
import { Camera, Shield, PrinterIcon as Printer3d, Code2, Factory, FlaskRoundIcon as Flask } from 'lucide-react'
import Link from "next/link"
import { usePathname } from "next/navigation"

const items = [
  {
    title: "Healthcare",
    href: "/healthcare",
    icon: Camera
  },
  {
    title: "Insurance",
    href: "/insurance",
    icon: Shield
  },
  {
    title: "3D Printing",
    href: "/3d-printing",
    icon: Printer3d
  },
  {
    title: "Software Factory",
    href: "/software-factory",
    icon: Code2
  },
  {
    title: "Production Lines",
    href: "/production",
    icon: Factory
  },
  {
    title: "Raw Materials",
    href: "/materials",
    icon: Flask
  }
]

export function MainNav() {
  const pathname = usePathname()

  return (
    <nav className="border-b">
      <div className="flex h-16 items-center px-4">
        <div className="flex items-center space-x-4 lg:space-x-6">
          {items.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center text-sm font-medium transition-colors hover:text-primary",
                pathname === item.href
                  ? "text-primary"
                  : "text-muted-foreground"
              )}
            >
              <item.icon className="mr-2 h-4 w-4" />
              {item.title}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  )
}

